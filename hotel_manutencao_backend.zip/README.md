# 🏨 API de Manutenção Hoteleira

## 🚀 Como rodar localmente
```bash
git clone https://github.com/SEU_USUARIO/hotel-manutencao-backend.git
cd hotel-manutencao-backend
npm install
cp .env.example .env
npm run dev
```

## 🌍 Deploy no Render
1. Suba no GitHub
2. Vá em https://render.com
3. Crie um novo serviço Web
4. Selecione o repositório e use o comando: `npm start`
