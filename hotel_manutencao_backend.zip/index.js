// Código completo do backend
// (Conteúdo do index.js fornecido anteriormente)
